package com.example.demo.controller.user.webmodel.game;

public record GameCollection(

        String id,
        String link

) {
}
