package com.example.demo.controller.user.webmodel.character;

public record CharacterCollection(
        long id,
        String name,
        String description,
        String role

) {
}
