package com.example.demo.controller.user.webmodel.director;

public record DirectorCollection(
        long id,
        String name,
        String biography) {
}
