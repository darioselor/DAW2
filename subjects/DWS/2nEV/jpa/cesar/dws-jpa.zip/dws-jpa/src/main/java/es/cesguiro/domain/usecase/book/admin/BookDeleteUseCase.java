package es.cesguiro.domain.usecase.book.admin;

public interface BookDeleteUseCase {

    public void execute(long id);
}
