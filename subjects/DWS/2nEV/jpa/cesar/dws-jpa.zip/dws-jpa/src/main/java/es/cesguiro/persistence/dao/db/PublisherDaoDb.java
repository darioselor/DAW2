package es.cesguiro.persistence.dao.db;

import es.cesguiro.domain.model.Publisher;

public interface PublisherDaoDb extends GenericDaoDb<Publisher> {
}
