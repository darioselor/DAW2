package es.cesguiro.persistence.dao.db;

import es.cesguiro.domain.model.Category;

public interface CategoryDaoDb extends GenericDaoDb<Category> {
}
