package es.cesguiro.controller.admin.webmodel.book;

public record BookCollection(
        String isbn,
        String title
) { }
