package es.cesguiro.controller.user.webmodel.publisher;

public record PublisherCollection(
        long id,
        String name
) {
}
