package es.cesguiro.controller.user.webmodel.author;

public record AuthorCollection(
        long id,
        String name
) {
}
