package es.cesguiro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DwsJpaApplication {
    public static void main(String[] args) {
        SpringApplication.run(DwsJpaApplication.class, args);
    }
}