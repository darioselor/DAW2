package es.cesguiro.domain.usecase.book;

public interface BookCountUseCase {

    long execute();
}
