package com.examen.LuisSerrano.peresistence.dao.db.jdbc;

import com.examen.LuisSerrano.domain.entity.Game;
import com.examen.LuisSerrano.domain.entity.jpa.GameEntity;
import com.examen.LuisSerrano.domain.repository.JPA.GameJpaRepository;
import com.examen.LuisSerrano.peresistence.dao.db.jdbc.mapper.Jpa.GameJpaMapper;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;

@Component
@Primary
@RequiredArgsConstructor
public class GameDaoJpa implements GameDaoDb {

    private final GameJpaRepository gameJpaRepository;

    @Override
    public Optional<Game> findByGameCode(String gameCode) {
        return gameJpaRepository.findByGameCode(gameCode)
                .map(GameJpaMapper.INSTANCE::toGame);
    }

    @Override
    public List<Game> getAll() {
        return gameJpaRepository.findAll()
                .stream()
                .map(GameJpaMapper.INSTANCE::toGame)
                .toList();
    }

    @Override
    public void insert(Game game) {
        if (gameJpaRepository.existsByGameCode(game.getGameCode())) {
            throw new RuntimeException("El juego con código " + game.getGameCode() + " ya existe.");
        }
        GameEntity gameEntity = GameJpaMapper.INSTANCE.toGameEntity(game);
        gameJpaRepository.save(gameEntity);
    }

    @Override
    public void update(Game game) {
        Optional<GameEntity> existingGame = gameJpaRepository.findByGameCode(game.getGameCode());

        if (existingGame.isEmpty()) {
            throw new RuntimeException("No se puede actualizar: el juego con código " + game.getGameCode() + " no existe.");
        }

        GameEntity gameEntity = GameJpaMapper.INSTANCE.toGameEntity(game);
        gameJpaRepository.save(gameEntity);
    }

    @Override
    public void delete(String gameCode) {
        if (!gameJpaRepository.existsByGameCode(gameCode)) {
            throw new RuntimeException("No se puede eliminar: el juego con código " + gameCode + " no existe.");
        }
        gameJpaRepository.deleteByGameCode(gameCode);
    }
}
