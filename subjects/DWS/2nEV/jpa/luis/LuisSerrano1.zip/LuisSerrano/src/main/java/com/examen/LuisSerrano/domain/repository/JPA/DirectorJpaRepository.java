package com.examen.LuisSerrano.domain.repository.JPA;


import com.examen.LuisSerrano.domain.entity.jpa.DirectorEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DirectorJpaRepository extends JpaRepository<DirectorEntity, Long> {
}

