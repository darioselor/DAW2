package com.examen.LuisSerrano.domain.service;



import com.examen.LuisSerrano.domain.entity.Game;
import com.examen.LuisSerrano.domain.entity.GameDetailsDTO;
import com.examen.LuisSerrano.domain.entity.GameSummaryDTO;

import java.util.List;
import java.util.Optional;

public interface GameService {
    List<GameSummaryDTO> getAll();
    Optional<GameDetailsDTO> getGameDetails(String gameCode);
    void insert(Game game);
    void update(Game game);
    void delete(String gameCode);
}


