package com.examen.LuisSerrano.domain.service.impl;

import com.examen.LuisSerrano.domain.entity.Game;
import com.examen.LuisSerrano.domain.entity.GameDetailsDTO;
import com.examen.LuisSerrano.domain.entity.GameSummaryDTO;
import com.examen.LuisSerrano.domain.service.GameService;
import com.examen.LuisSerrano.peresistence.dao.db.jdbc.GameDaoDb;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class GameServiceImpl implements GameService {

    private final GameDaoDb gameDaoDb;

    @Override
    public List<GameSummaryDTO> getAll() {
        return gameDaoDb.getAll().stream()
                .map(game -> new GameSummaryDTO(game.getTitle(),
                        "http://localhost:8080/api/games/" + game.getGameCode()))
                .collect(Collectors.toList());
    }

    @Override
    public Optional<GameDetailsDTO> getGameDetails(String gameCode) {
        return gameDaoDb.findByGameCode(gameCode)
                .map(GameDetailsDTO::fromGame);
    }

    @Override
    public void insert(Game game) {
        gameDaoDb.insert(game);
    }

    @Override
    public void update(Game game) {
        gameDaoDb.update(game);
    }

    @Override
    public void delete(String gameCode) {
        gameDaoDb.delete(gameCode);
    }
}

