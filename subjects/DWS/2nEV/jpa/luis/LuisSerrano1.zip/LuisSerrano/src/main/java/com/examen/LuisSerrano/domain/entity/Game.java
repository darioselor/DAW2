package com.examen.LuisSerrano.domain.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Game {
    private Long id;
    private String gameCode;
    private String title;
    private Integer releaseYear;
    private String description;
    private Director director;
    private List<GameCharacter> gameCharacters;
}
