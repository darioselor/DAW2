package com.examen.LuisSerrano.peresistence.dao.db.jdbc.mapper;

public class GameRowMapper {
}
