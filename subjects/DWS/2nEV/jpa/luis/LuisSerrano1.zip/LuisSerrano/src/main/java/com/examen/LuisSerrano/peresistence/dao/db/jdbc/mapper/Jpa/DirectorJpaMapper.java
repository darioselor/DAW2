package com.examen.LuisSerrano.peresistence.dao.db.jdbc.mapper.Jpa;

import com.examen.LuisSerrano.domain.entity.Director;
import com.examen.LuisSerrano.domain.entity.jpa.DirectorEntity;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface DirectorJpaMapper {
    Director toDirector(DirectorEntity directorEntity);
    DirectorEntity toDirectorEntity(Director director);
}
