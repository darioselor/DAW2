package com.examen.LuisSerrano.peresistence.dao.db.jdbc.mapper.Jpa;

import com.examen.LuisSerrano.domain.entity.GameCharacter;
import com.examen.LuisSerrano.domain.entity.jpa.GameCharacterEntity;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface GameCharacterJpaMapper {
    GameCharacter toGameCharacter(GameCharacterEntity characterEntity);
    GameCharacterEntity toGameCharacterEntity(GameCharacter character);
}
