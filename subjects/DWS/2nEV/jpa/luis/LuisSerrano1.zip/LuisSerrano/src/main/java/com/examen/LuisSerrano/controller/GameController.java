package com.examen.LuisSerrano.controller;


import com.examen.LuisSerrano.domain.entity.Game;
import com.examen.LuisSerrano.domain.entity.GameDetailsDTO;
import com.examen.LuisSerrano.domain.entity.GameSummaryDTO;
import com.examen.LuisSerrano.domain.service.GameService;
import lombok.RequiredArgsConstructor;
import lombok.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/games")
@RequiredArgsConstructor
public class GameController {

    private final GameService gameService;

    @GetMapping
    public ResponseEntity<List<GameSummaryDTO>> getAllGames() {
        return ResponseEntity.ok(gameService.getAll());
    }

    @GetMapping("/{gameCode}")
    public ResponseEntity<GameDetailsDTO> getGameDetails(@PathVariable String gameCode) {
        Optional<GameDetailsDTO> gameDetails = gameService.getGameDetails(gameCode);
        return gameDetails.map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }
}

