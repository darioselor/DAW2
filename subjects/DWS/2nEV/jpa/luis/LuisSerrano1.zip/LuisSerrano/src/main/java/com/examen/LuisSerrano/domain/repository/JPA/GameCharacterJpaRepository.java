package com.examen.LuisSerrano.domain.repository.JPA;

import com.examen.LuisSerrano.domain.entity.jpa.GameCharacterEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface GameCharacterJpaRepository extends JpaRepository<GameCharacterEntity, Long> {
}

