package com.examen.LuisSerrano.peresistence.dao.db.jdbc.mapper.Jpa;

import com.examen.LuisSerrano.domain.entity.Game;
import com.examen.LuisSerrano.domain.entity.jpa.GameEntity;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper
public interface GameJpaMapper {

    GameJpaMapper INSTANCE = Mappers.getMapper(GameJpaMapper.class);

    @Mapping(source = "gameCharacters", target = "gameCharacters") // Ajustado aquí
    Game toGame(GameEntity gameEntity);

    @Mapping(source = "gameCharacters", target = "gameCharacters") // Ajustado aquí
    GameEntity toGameEntity(Game game);
}


