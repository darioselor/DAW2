package com.examen.LuisSerrano.domain.repository.JPA;


import com.examen.LuisSerrano.domain.entity.jpa.GameEntity;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface GameJpaRepository extends JpaRepository<GameEntity, String> {
    Optional<GameEntity> findByGameCode(String gameCode);
    boolean existsByGameCode(String gameCode);
    void deleteByGameCode(String gameCode);
}

