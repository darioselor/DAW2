package com.examen.LuisSerrano.peresistence.dao.db.jdbc;

import com.examen.LuisSerrano.domain.entity.Game;

import java.util.List;
import java.util.Optional;

public interface GameDaoDb {
    Optional<Game> findByGameCode(String gameCode);
    List<Game> getAll();
    void insert(Game game);
    void update(Game game);
    void delete(String gameCode);
}

