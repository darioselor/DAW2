package com.examen.LuisSerrano.domain.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class GameDetailsDTO {
    private String gameCode;
    private String title;
    private int releaseYear;
    private String description;
    private Director director;
    private List<CharacterDTO> charactersList;

    public static GameDetailsDTO fromGame(Game game) {
        List<CharacterDTO> characterDTOs = game.getGameCharacters() != null
                ? game.getGameCharacters().stream().map(CharacterDTO::fromCharacter).toList()
                : new ArrayList<>();

        return new GameDetailsDTO(
                game.getGameCode(),
                game.getTitle(),
                game.getReleaseYear(),
                game.getDescription(),
                game.getDirector(),
                characterDTOs
        );
    }
}


