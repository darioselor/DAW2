package com.examen.LuisSerrano.peresistence.dao.cache;

public interface GenericDaoCache<T> {
    void save(T t);
    void clearCache();
}
