package com.example.demo.domain.usecase.AuthorUseCase;

import com.example.demo.domain.model.Author;

public interface AuthorUpdateUseCase {

    void execute(Author author);
    
}
