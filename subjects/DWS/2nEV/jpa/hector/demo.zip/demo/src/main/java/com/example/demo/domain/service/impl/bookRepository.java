package com.example.demo.domain.service.impl;

public class bookRepository {

}
