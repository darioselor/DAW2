package com.darioselor.ArquitecturaPorCapas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ArquitecturaPorCapasApplicationTests {

	@Test
	void contextLoads() {
	}

}
