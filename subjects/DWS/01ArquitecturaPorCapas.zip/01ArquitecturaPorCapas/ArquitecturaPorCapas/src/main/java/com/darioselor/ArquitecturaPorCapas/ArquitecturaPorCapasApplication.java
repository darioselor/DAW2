package com.darioselor.ArquitecturaPorCapas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ArquitecturaPorCapasApplication {

	public static void main(String[] args) {
		SpringApplication.run(ArquitecturaPorCapasApplication.class, args);
	}

}
