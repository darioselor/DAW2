package fpmislata.examen.domain.usecase.order.common;

public interface OrderCountUseCase {
    int execute();
}
