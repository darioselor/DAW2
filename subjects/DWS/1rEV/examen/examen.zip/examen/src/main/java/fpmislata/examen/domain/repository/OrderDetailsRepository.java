package fpmislata.examen.domain.repository;

import fpmislata.examen.domain.model.OrderDetails;

public interface OrderDetailsRepository {

    OrderDetails getOrderDetailsByOrderID(Long id);
}
