package fpmislata.examen.domain.usecase.order.user.model;

public class UserUser {

    private String name;
    private String address;
    private boolean admin;

    public UserUser(String name, String address, boolean adming) {
        this.name = name;
        this.address = address;
        this.admin = admin;
    }

}
