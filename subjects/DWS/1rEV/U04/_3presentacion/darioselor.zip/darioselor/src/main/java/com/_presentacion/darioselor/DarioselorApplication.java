package com._presentacion.darioselor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DarioselorApplication {

	public static void main(String[] args) {
		SpringApplication.run(DarioselorApplication.class, args);
	}

}
