package com._presentacion.darioselor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DarioselorApplicationTests {

	@Test
	void contextLoads() {
	}

}
