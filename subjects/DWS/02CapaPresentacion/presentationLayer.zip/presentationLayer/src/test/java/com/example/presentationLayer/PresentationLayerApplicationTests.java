package com.example.presentationLayer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PresentationLayerApplicationTests {

	@Test
	void contextLoads() {
	}

}
